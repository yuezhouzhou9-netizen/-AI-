# 生成质检与迭代规则

## 必过项（每张图生成后检查）

每张图必须同时满足以下条件，否则重生成：

| 检查项 | 标准 |
|---|---|
| 主角必须戴星星天线头盔 | 头盔、蓝色螺旋天线、顶端发光星星清晰可见，不能省略或变形 |
| 主角参与核心动作 | 主角在做与主题直接相关的事，不是站在旁边看 |
| 主角外形正确 | 粉色猪鼻、粉色耳朵、蓝色面罩、胸前"7"徽章、蓝紫披风均可见 |
| 背景纯白 | 不允许米色、暖灰、纸张纹理、复杂渐变、地面墙面 |
| 风格一致 | 圆润 3D 科技吉祥物风格，光滑材质，柔和光影 |
| 留白充足 | 主体占画面 40%-55%，至少 35% 空白 |
| 批注数量克制 | 最多 5-8 处中文批注，每处 2-8 个字 |
| 无类型标题 | 左上角不出现"Workflow / 流程图 / 系统架构"等类型名称 |
| 颜色克制 | 科技蓝用于主流程，橙色辅助，红色用于重点，紫色用于补充说明，不滥用 |

## 居中检查

如果主体（角色+主要物件）的视觉重心明显偏左或偏右，就是居中失败。判断方法：

想象把画面沿垂直中线对折——如果主体完全在左半区而右侧只有批注文字，就是偏移，需要重生成。

重生成时在 Composition 段加入居中锚点语句（参考 `prompt-template.md` 中的 Centering anchor 选项），并删掉任何"右侧大片留白"或"左侧放角色"的描述。

## 失败信号

出现以下情况，重生成或局部编辑：

- 主角没有戴星星天线头盔，或天线/星星形状不对
- 主角只是站在角落里看，没有参与核心动作
- 主角缺少猪鼻、猪耳、"7"徽章、披风等关键识别特征
- 主体明显偏向画面一侧，另一侧只有批注文字
- 画面太满，没有留白，像 PPT 或说明书
- 中文批注太多（超过 8 处）或有明显错字
- 颜色太多太乱，失去克制感
- 背景出现复杂场景、地面、墙面或环境

## 局部编辑提示

**去掉左上角标题：**

```text
Edit the provided image. Remove only the handwritten title "{要删除的文字}" and its underline from the top-left corner. Fill that area with the same clean white background. Preserve everything else exactly: characters, labels, paths, line style, composition, aspect ratio, and image quality. Do not add any new text or objects.
```

**补回星星天线头盔（若生成结果遗漏）：**

```text
Edit the provided image. The cyber pig mascot is missing the star antenna helmet. Add a white rounded space helmet with a blue spiral antenna and a glowing light blue five-pointed star on top. Keep the pink ears, blue visor, and other features consistent. Preserve all other elements exactly.
```

**增强主角参与感：**

```text
Regenerate this illustration with the same core meaning and simple layout, but make the cyber pig mascot more central to the conceptual action. He should be doing the strange or interesting work that explains the idea, not standing beside the diagram. Keep it clean, sparse, 3D cute tech style, energetic but not overly cute.
```

**修复居中偏移：**

```text
Regenerate this illustration with the same theme and visual style, but reposition the main subject (cyber pig + main object) to be horizontally centered on the canvas (x=50%). Distribute annotations around all four sides of the subject, not clustered on one side. Keep equal white space on both left and right.
```

## 迭代原则

不要无限迭代同一张图。如果两次重生成后问题依然存在，换一个隐喻或换一种结构类型，而不是继续调整同一个提示词。

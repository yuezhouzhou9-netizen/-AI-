# 生图提示词模板

每张图单独生成。根据正文内容替换变量，不要把多张图拼在一张里。

生成时**必须**将 `assets/ip-reference/ip-character-sheet.png` 作为 reference image 传入，以保证角色外形一致。

```text
Generate one standalone 16:9 horizontal Chinese article illustration.

Visual DNA:
Pure white background. Clean 3D-rendered cute tech mascot style, smooth rounded surfaces, soft shadows, glossy material. Lots of empty white space (main subject under 50% of canvas). Sparse blue/orange/red/purple handwritten Chinese annotations. Cute tech product-sketch feeling. No complex backgrounds, no realistic scenes, no PPT infographic look, no adult proportions, no flat vector cartoon.

Recurring IP character required:
A cute Q-version cyber pig mascot named "运宝小七". He wears a white rounded space helmet with a blue spiral antenna on top and a glowing light blue five-pointed star at the tip (MOST important feature, NEVER omit). Transparent blue holographic visor covering the eyes. Two pink pig ears sticking out of the helmet. Pink pig snout with two black nostrils visible in front of the visor. White one-piece space suit with rounded Q-version body. Blue bow tie at neck. Circular dark blue badge on chest with a glowing white "7" symbol. Blue-purple gradient cape flowing behind. Purple ring stripes on arms and legs. Blue circular earphone modules on helmet sides. Purple tech circuit lines on helmet surface. He must perform the core conceptual action, not decorate the scene. Keep his expression energetic, brave, focused, or sunny — not sad or angry.

Character color palette:
Suit white: #F8F9FA | Helmet/visor/antenna/earphone/bow tie: #3B9DF5 | Star glow: #7DD3FC | Circuit/ring stripes/cape inner: #7B5FC4 | Skin/snout: #FFB6C1 | Blush: #FFD1D9 | Badge background: #1B4F8C | Badge "7": #FFFFFF | Eyes/nostrils: #2C2C2A

Theme:
{正文配图主题}

Structure type:
{结构类型：Workflow / 系统局部 / 前后对比 / 角色状态 / 概念隐喻 / 方法分层 / 地图路线 / 小漫画分镜}

Core idea:
{这张图要表达的核心意思}

Composition:
{具体画面：主角在哪里、正在做什么、主要物件是什么、信息如何流动}

Suggested elements:
{元素1} / {元素2} / {元素3} / {元素4}

Chinese handwritten labels:
{标注词1} / {标注词2} / {标注词3} / {标注词4} / {可选标注词5}

Color use:
Use character's natural colors for the cyber pig. Tech blue for main flow/path/arrows. Orange for secondary flow or action emphasis. Red only for key warnings/problems/results. Purple for secondary notes or tech/system state. Keep colors restrained.

Centering anchor (REQUIRED — pick one and include in Composition):
- Single subject: "The main subject is anchored at the horizontal center of the canvas (x=50%). Leave roughly equal white space on both left and right sides."
- Horizontal sequence: "The sequence spans from x=15% to x=85% of the canvas width, centered horizontally with equal margins on both sides."
- Left-right split: "The vertical dividing line sits exactly at x=50%. Both halves have equal visual weight and similar element density."
- Vertical layers: "All layer bands are horizontally centered, spanning from x=12% to x=75%. Annotations appear in the right margin (x=78%-95%)."

Annotation placement: Distribute handwritten labels around all sides of the main subject (top, bottom, left, right). Do NOT cluster all annotations on one side only — this causes visual imbalance. Never write "large blank white space on the right" or "character on the left" in the Composition description.

Constraints:
One image explains only one core structure. Keep the main subject around 40%-55% of the canvas. Preserve roughly equal white space on both sides of the subject. Use at most 5-8 short handwritten Chinese labels. Do not write a title in the top-left corner. Do not write the structure type on the image. Do not make it a formal diagram, course slide, or dense explainer. Do not copy prior examples; invent a fresh visual metaphor for this specific article. It should be clear but not instructional, interesting but not childish, energetic but not messy. The star antenna helmet must be visible in every image.
```

## 图像编辑提示

去掉左上角标题：

```text
Edit the provided image. Remove only the handwritten title "{要删除的文字}" and its underline from the top-left corner. Fill that area with the same clean white background. Preserve everything else exactly: characters, labels, paths, line style, composition, aspect ratio, and image quality. Do not add any new text or objects.
```

增强主角参与感：

```text
Regenerate this illustration with the same core meaning and simple layout, but make the cyber pig mascot more central to the conceptual action. He should be doing the strange or interesting work that explains the idea, not standing beside the diagram. Keep it clean, sparse, 3D cute tech style, energetic but not overly cute.
```

天线头盔修复提示（若生成结果遗漏星星天线头盔）：

```text
Edit the provided image. The cyber pig mascot is missing the star antenna helmet. Add a white rounded space helmet with a blue spiral antenna and a glowing light blue five-pointed star on top. Keep the pink ears, blue visor, and other features consistent. Preserve all other elements exactly.
```

居中修复提示（若主体偏移）：

```text
Regenerate this illustration with the same theme and visual style, but reposition the main subject (cyber pig + main object) to be horizontally centered on the canvas (x=50%). Distribute annotations around all four sides of the subject, not clustered on one side. Keep equal white space on both left and right.
```